# earn-edge
---

## System Links

#### Landing Page: [http://localhost/earn-edge/](http://localhost/earn-edge/)

#### Admin Page: [http://localhost/earn-edge/login](http://localhost/earn-edge/login)

---

## System Default Account

- Admin account: 
  - email: admin@admin.com
  - password: 1

- System Link
 - earn-edge.infinityfreeapp.com

- Gmail
  - matthew.gentolea@gsc.edu.ph
  - matthew12345

  - mariellejoygalon110@gmail.com
  - marielle_2002

- Infinity Free Account
 - user name: if0_36466872
 - password: i6SVuVR3nI